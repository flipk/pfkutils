;; -*- no-byte-compile: t; lexical-binding: nil -*-
(define-package "counsel-pydoc" "20171018.2042"
  "Run pydoc with counsel."
  '((emacs "24.3")
    (ivy   "0.9.1"))
  :url "https://github.com/co-dh/pydoc_utils"
  :commit "08a4a1020da3d06604156303024c8a5e31ec36e4"
  :revdesc "08a4a1020da3"
  :keywords '("completion" "matching")
  :authors '(("Hao" . "Deng(denghao8888@gmail.com)"))
  :maintainers '(("Hao" . "Deng(denghao8888@gmail.com)")))
